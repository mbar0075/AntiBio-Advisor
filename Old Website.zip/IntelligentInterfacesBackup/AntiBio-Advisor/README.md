# AntiBio-Advisor
An intelligent interface project targeted towards educating people of different ages about when and why to use antibiotic medication.

# Libraries used
- [Bootstrap template](https://startbootstrap.com/theme/grayscale#google_vignette)

# Note

If streamlit_app.py is not used .devcontainor & .streamlit can be safely removed alongside streamlit_app.py .